from tkinter import *

import time
import datetime	
import random
import sys
	
root=Tk()
root.geometry("4160x3120")
root.title("HOTEL")
root.configure(background='yellow')

Tops = Frame(root,bg='RED',bd=20,pady=5,relief=RIDGE)
Tops.pack(side=TOP)

lblTitle=Label(Tops,font=('arial',60,'bold'),text='HOTEL TUMKURU',bd=21,bg='YELLOW',fg="red",justify=CENTER)
lblTitle.grid(row=0)


ReceiptCal_F = Frame(root,bg='red',bd=10,relief=RIDGE)
ReceiptCal_F.pack(side=RIGHT)

Buttons_F=Frame(ReceiptCal_F,bg='red',bd=3,relief=RIDGE)
Buttons_F.pack(side=BOTTOM)

Cal_F=Frame(ReceiptCal_F,bg='red',bd=6,relief=RIDGE)
Cal_F.pack(side=TOP)

Receipt_F=Frame(ReceiptCal_F,bg='red',bd=4,relief=RIDGE)
Receipt_F.pack(side=BOTTOM)

MenuFrame = Frame(root,bg='YELLOW',bd=10,relief=RIDGE)
MenuFrame.pack(side=LEFT)
Cost_F=Frame(MenuFrame,bg='YELLOW',bd=4)
Cost_F.pack(side=BOTTOM)
Drinks_F=Frame(MenuFrame,bg='YELLOW',bd=4)
Drinks_F.pack(side=TOP)


Drinks_F=Frame(MenuFrame,bg='YELLOW',bd=4,relief=RIDGE)
Drinks_F.pack(side=LEFT)
Food_F=Frame(MenuFrame,bg='YELLOW',bd=4,relief=RIDGE)
Food_F.pack(side=RIGHT)
 
Images1 = PhotoImage(file = "/home/abhishekbj/python project/image")
Images2 = PhotoImage(file = "/home/abhishekbj/python project/image")
image=Image.open("image1.gif")
photo=ImageTk.PhotoImage(image)
lab=Label(image = Images1)
lab.pack()
Label(image = Images2).grid(row = 1, column = 3,sticky=W,side="right")
###################################################variables################################################

var1=IntVar()
var2=IntVar()
var3=IntVar()
var4=IntVar()
var5=IntVar()
var6=IntVar()
var7=IntVar()
var8=IntVar()
var9=IntVar()
var10=IntVar()
var11=IntVar()
var12=IntVar()
var13=IntVar()
var14=IntVar()
var15=IntVar()
var16=IntVar()

DateofOrder = StringVar()
Receipt_Ref = StringVar()
PaidTax = StringVar()
SubTotal = StringVar()
TotalCost = StringVar()
CostofFood = StringVar()
CostofDrinks = StringVar()
ServiceCharge = StringVar()

text_Input = StringVar()
#operator = ""

E_coffee = StringVar()
E_tea = StringVar()
E_badammilk = StringVar()
E_applejuice = StringVar()
E_watermelonjuice = StringVar()
E_lassi = StringVar()
E_milkshek = StringVar()
E_coldcoffee = StringVar()

E_masaladosa = StringVar()
E_pulliyogare = StringVar()
E_pizza = StringVar()
E_ricebath = StringVar()
E_sandwich = StringVar()
E_biriyani = StringVar()
E_northindian = StringVar()
E_southindian = StringVar()

E_coffee.set("0")
E_tea.set("0")
E_badammilk.set("0")
E_applejuice.set("0")
E_watermelonjuice.set("0")
E_lassi.set("0")
E_milkshek.set("0")
E_coldcoffee.set("0")

E_masaladosa.set("0")
E_pulliyogare.set("0")
E_pizza.set("0")
E_ricebath.set("0")
E_sandwich.set("0")
E_biriyani.set("0")
E_northindian.set("0")
E_southindian.set("0")

DateofOrder.set(time.strftime("%d/%m/%y"))

##########################################Function Declaration####################################################


def Reset():

	PaidTax.set("")
	SubTotal.set("")
	TotalCost.set("")
	CostofFood.set("")
	CostofDrinks.set("")
	ServiceCharge.set("")
	txtReceipt.delete("1.0",END)


	E_coffee.set("0")
	E_tea.set("0")
	E_badammilk.set("0")
	E_applejuice.set("0")
	E_watermelonjuice.set("0")
	E_lassi.set("0")
	E_milkshek.set("0")
	E_coldcoffee.set("0")

	E_masaladosa.set("0")
	E_pulliyogare.set("0")
	E_pizza.set("0")
	E_ricebath.set("0")
	E_sandwich.set("0")
	E_biriyani.set("0")
	E_northindian.set("0")
	E_southindian.set("0")

	var1.set(0)
	var2.set(0)
	var3.set(0)
	var4.set(0)
	var5.set(0)
	var6.set(0)
	var7.set(0)
	var8.set(0)
	var9.set(0)
	var10.set(0)
	var11.set(0)
	var12.set(0)
	var13.set(0)
	var14.set(0)
	var15.set(0)
	var16.set(0)

	txtcoffee.configure(state=DISABLED)
	txtTea.configure(state=DISABLED)
	txtBadammilk.configure(state=DISABLED)
	txtapple.configure(state=DISABLED)
	txtwatermelon.configure(state=DISABLED)
	txtlassi.configure(state=DISABLED)
	txtmilkshek.configure(state=DISABLED)
	txtColdCoffee.configure(state=DISABLED)
	txtmasalaDosa.configure(state=DISABLED)
	txtpuliyogare.configure(state=DISABLED)
	txtPizza.configure(state=DISABLED)
	txtBurger.configure(state=DISABLED)
	txtSandwich.configure(state=DISABLED)
	txtBiriyani.configure(state=DISABLED)
	txtnorthIndian.configure(state=DISABLED)
	txtsouthIndian.configure(state=DISABLED)


def CostofItem():
	Item1=float(E_coffee.get())
	Item2=float(E_tea.get())
	Item3=float(E_badammilk.get())
	Item4=float(E_applejuice.get())
	Item5=float(E_watermelonjuice.get())
	Item6=float(E_lassi.get())
	Item7=float(E_milkshek.get())
	Item8=float(E_coldcoffee.get())

	Item9=float(E_masaladosa.get())
	Item10=float(E_pulliyogare.get())
	Item11=float(E_pizza.get())
	Item12=float(E_ricebath.get())
	Item13=float(E_sandwich.get())
	Item14=float(E_biriyani.get())
	Item15=float(E_northindian.get())
	Item16=float(E_southindian.get())

	PriceofDrinks =(Item1 * 20) + (Item2 * 20) + (Item3 * 30) + (Item4 * 50) + (Item5 * 50) + (Item6 * 50) + (Item7 * 60) + (Item8 * 70)

	PriceofFood =(Item9 * 60) + (Item10 * 50) + (Item11 * 100) + (Item12 * 80) + (Item13 * 100) + (Item14 * 120) + (Item15 * 240) + (Item16 * 180)



	DrinksPrice = "Rs",str('%.2f'%(PriceofDrinks))
	FoodPrice =  "Rs",str('%.2f'%(PriceofFood))
	CostofFood.set(FoodPrice)
	CostofDrinks.set(DrinksPrice)
	SC = "Rs",str('%.2f'%(1.59))
	ServiceCharge.set(SC)

	SubTotalofITEMS = "Rs",str('%.2f'%(PriceofDrinks + PriceofFood + 1.59))
	SubTotal.set(SubTotalofITEMS)

	Tax = "Rs",str('%.2f'%((PriceofDrinks + PriceofFood + 1.59) * 0.15))
	PaidTax.set(Tax)

	TT=((PriceofDrinks + PriceofFood + 1.59) * 0.15)
	TC="Rs",str('%.2f'%(PriceofDrinks + PriceofFood + 1.59 + TT))
	TotalCost.set(TC)


def chkcoffee():
	if(var1.get() == 1):
		txtcoffee.configure(state = NORMAL)
		txtcoffee.focus()
		txtcoffee.delete('0',END)
		E_coffee.set("")
	elif(var1.get() == 0):
		txtcoffee.configure(state = DISABLED)
		E_coffee.set("0")

def chktea():
	if(var2.get() == 1):
		txtTea.configure(state = NORMAL)
		txtTea.focus()
		txtTea.delete('0',END)
		E_tea.set("")
	elif(var2.get() == 0):
		txtTea.configure(state = DISABLED)
		E_tea.set("0")

def chk_badammilk():
	if(var3.get() == 1):
		txtBadammilk.configure(state = NORMAL)
		txtBadammilk.delete('0',END)
		txtBadammilk.focus()
	elif(var3.get() == 0):
		txtBadammilk.configure(state = DISABLED)
		E_badammilk.set("0")

def chkapple_juice():
	if(var4.get() == 1):
		txtapple.configure(state = NORMAL)
		txtapple.delete('0',END)
		txtapple.focus()
	elif(var4.get() == 0):
		txtapple.configure(state = DISABLED)
		E_applejuice.set("0")

def chk_watermelon():
	if(var5.get() == 1):
		txtwatermelon.configure(state = NORMAL)
		txtwatermelon.delete('0',END)
		txtwatermelon.focus()
	elif(var5.get() == 0):
		txtwatermelon.configure(state = DISABLED)
		E_watermelonjuice.set("0")

def chk_lussi():
	if(var6.get() == 1):
		txtlassi.configure(state = NORMAL)
		txtlassi.delete('0',END)
		txtlassi.focus()
	elif(var6.get() == 0):
		txtlassi.configure(state = DISABLED)
		E_lassi.set("0")

def chk_milkshek():
	if(var7.get() == 1):
		txtmilkshek.configure(state = NORMAL)
		txtmilkshek.delete('0',END)
		txtmilkshek.focus()
	elif(var7.get() == 0):
		txtmilkshek.configure(state = DISABLED)
		E_milkshek.set("0")

def chk_ColdCoffee():
	if(var8.get() == 1):
		txtColdCoffee.configure(state = NORMAL)
		txtColdCoffee.delete('0',END)
		txtColdCoffee.focus()
	elif(var8.get() == 0):
		txtColdCoffee.configure(state = DISABLED)
		E_coldcoffee.set("0")

def chk_dosa():
	if(var9.get() == 1):
		txtmasalaDosa.configure(state = NORMAL)
		txtmasalaDosa.delete('0',END)
		txtmasalaDosa.focus()
	elif(var9.get() == 0):
		txtmasalaDosa.configure(state = DISABLED)
		E_masaladosa.set("0")

def chk_puliyogare():
	if(var10.get() == 1):
		txtpuliyogare.configure(state = NORMAL)
		txtpuliyogare.delete('0',END)
		txtpuliyogare.focus()
	elif(var10.get() == 0):
		txtpuliyogare.configure(state = DISABLED)
		E_pulliyogare.set("0")

def chk_pizza():
	if(var11.get() == 1):
		txtPizza.configure(state = NORMAL)
		txtPizza.delete('0',END)
		txtPizza.focus()
	elif(var11.get() == 0):
		txtPizza.configure(state = DISABLED)
		E_pizza.set("0")

def chk_burger():
	if(var12.get() == 1):
		txtBurger.configure(state = NORMAL)
		txtBurger.delete('0',END)
		txtBurger.focus()
	elif(var12.get() == 0):
		txtBurger.configure(state = DISABLED)
		E_ricebath.set("0")

def chk_sandwich():
	if(var13.get() == 1):
		txtSandwich.configure(state = NORMAL)
		txtSandwich.delete('0',END)
		txtSandwich.focus()
	elif(var13.get() == 0):
		txtSandwich.configure(state = DISABLED)
		E_sandwich.set("0")

def chk_Biriyani():
	if(var14.get() == 1):
		txtBiriyani.configure(state = NORMAL)
		txtBiriyani.delete('0',END)
		txtBiriyani.focus()
	elif(var14.get() == 0):
		txtBiriyani.configure(state = DISABLED)
		E_biriyani.set("0")

def chk_northindian():
	if(var15.get() == 1):
		txtnorthIndian.configure(state = NORMAL)
		txtnorthIndian.delete('0',END)
		txtnorthIndian.focus()
	elif(var15.get() == 0):
		txtnorthIndian.configure(state = DISABLED)
		E_northindian.set("0")

def chk_southindian():
	if(var16.get() == 1):
		txtsouthIndian.configure(state = NORMAL)
		txtsouthIndian.delete('0',END)
		txtsouthIndian.focus()
	elif(var16.get() == 0):
		txtsouthIndian.configure(state = DISABLED)
		E_southindian.set("0")

def Receipt():
	txtReceipt.delete("1.0",END)
	x=random.randint(10908,500876)
	randomRef= str(x)
	Receipt_Ref.set("Bill"+ randomRef)

	
	txtReceipt.insert(END,'Receipt Ref:\t\t'+Receipt_Ref.get() +'\t\t'+ DateofOrder.get() +'\n')
	txtReceipt.insert(END,'Items\t\t'+'no of items\t\t'+"Cost of Items \n")
	if (int(E_coffee.get())!=0):
		txtReceipt.insert(END,'coffee:\t\t\t' + E_coffee.get() +'\n')

	if (int(E_tea.get())!=0):
		txtReceipt.insert(END,'tea:\t\t\t'+ E_tea.get()+'\n')
	if (int(E_badammilk.get())!=0):
		txtReceipt.insert(END,'BadamMilk:\t\t\t'+ E_badammilk.get()+'\n')
	if (int(E_applejuice.get())!=0):
		txtReceipt.insert(END,'apple_juice:\t\t\t'+ E_applejuice.get()+'\n')
	if (int(E_watermelonjuice.get())!=0):
		txtReceipt.insert(END,'watermelon_juice:\t\t\t'+ E_watermelonjuice.get()+'\n')
	if (int(E_lassi.get())!=0):
		txtReceipt.insert(END,'E_lassi:\t\t\t'+ E_lassi.get()+'\n')
	if (int(E_milkshek.get())!=0):
		txtReceipt.insert(END,'E_milkshek:\t\t\t'+ E_milkshek.get()+'\n')
	if (int(E_coldcoffee.get())!=0):
		txtReceipt.insert(END,'ColdCoffee:\t\t\t'+ E_coldcoffee.get()+'\n')
	if (int(E_masaladosa.get())!=0):
		txtReceipt.insert(END,'masala_dosa:\t\t\t'+ E_masaladosa.get()+'\n')
	if (int(E_pulliyogare.get())!=0):
		txtReceipt.insert(END,'puliyogare:\t\t\t'+ E_pulliyogare.get()+'\n')
	if (int(E_pizza.get())!=0):
		txtReceipt.insert(END,'E_pizza:\t\t\t'+ E_pizza.get()+'\n')
	if (int(E_ricebath.get())!=0):
		txtReceipt.insert(END,'HamBurger:\t\t\t'+ E_ricebath.get()+'\n')
	if (int(E_sandwich.get())!=0):
		txtReceipt.insert(END,'Sandwich:\t\t\t'+ E_sandwich.get()+'\n')
	if (int(E_biriyani.get())!=0):
		txtReceipt.insert(END,'Biriyani:\t\t\t'+ E_biriyani.get()+'\n')
	if (int(E_northindian.get())!=0):
		txtReceipt.insert(END,'NorthIndian_meals:\t\t\t'+ E_northindian.get()+'\n')
	if (int(E_southindian.get())!=0):
		txtReceipt.insert(END,'SouthIndian_meals:\t\t\t'+ E_southindian.get()+'\n')
	txtReceipt.insert(END,'Cost of Drinks:\t\t\t\t'+ CostofDrinks.get()+'\nTax Paid:\t\t\t\t'+PaidTax.get()+"\n")
	txtReceipt.insert(END,'Cost of Foods:\t\t\t\t'+ CostofFood.get()+'\nSubTotal:\t\t\t\t'+str(SubTotal.get())+"\n")
	txtReceipt.insert(END,'Service Charge:\t\t\t\t'+ ServiceCharge.get()+'\nTotal Cost:\t\t\t\t'+str(TotalCost.get())+"\n")

def iExit():
	sys.exit(0)

#########################################Drinks####################################################################
coffee=Checkbutton(Drinks_F,text='coffee',variable=var1,onvalue=1,offvalue=0,font=('arial',18,'bold'),
		            bg='yellow',fg="red",command=chkcoffee).grid(row=0,sticky=W)
tea=Checkbutton(Drinks_F,text='tea',variable=var2,onvalue=1,offvalue=0,font=('arial',18,'bold'),
		            bg='yellow',fg="red",command=chktea).grid(row=1,sticky=W)
BadamMilk=Checkbutton(Drinks_F,text='BadamMilk',variable=var3,onvalue=1,offvalue=0,font=('arial',18,'bold'),
		            bg='yellow',fg="red",command=chk_badammilk).grid(row=2,sticky=W)
apple_juice=Checkbutton(Drinks_F,text='apple_juice',variable=var4,onvalue=1,offvalue=0,font=('arial',18,'bold'),
		            bg='yellow',fg="red",command=chkapple_juice).grid(row=3,sticky=W)
watermelon_juice=Checkbutton(Drinks_F,text='watermelon_juice',variable=var5,onvalue=1,offvalue=0,font=('arial',18,'bold'),
		            bg='yellow',fg="red",command=chk_watermelon).grid(row=4,sticky=W)
lassi=Checkbutton(Drinks_F,text='E_lassi',variable=var6,onvalue=1,offvalue=0,font=('arial',18,'bold'),
		            bg='yellow',fg="red",command=chk_lussi).grid(row=5,sticky=W)
milkshek=Checkbutton(Drinks_F,text='E_milkshek',variable=var7,onvalue=1,offvalue=0,font=('arial',18,'bold'),
		            bg='yellow',fg="red",command=chk_milkshek).grid(row=6,sticky=W)
ColdCoffee=Checkbutton(Drinks_F,text='ColdCoffee',variable=var8,onvalue=1,offvalue=0,font=('arial',18,'bold'),
		            bg='yellow',fg="red",command=chk_ColdCoffee).grid(row=7,sticky=W)
##############################################Drink Entry###############################################################

txtcoffee = Entry(Drinks_F,font=('arial',16,'bold'),bd=8,width=6,justify=LEFT,state=DISABLED
		                ,textvariable=E_coffee)
txtcoffee.grid(row=0,column=1)

txtTea = Entry(Drinks_F,font=('arial',16,'bold'),bd=8,width=6,justify=LEFT,state=DISABLED
		                ,textvariable=E_tea)
txtTea.grid(row=1,column=1)

txtBadammilk = Entry(Drinks_F,font=('arial',16,'bold'),bd=8,width=6,justify=LEFT,state=DISABLED
		                ,textvariable=E_badammilk)
txtBadammilk.grid(row=2,column=1)

txtapple= Entry(Drinks_F,font=('arial',16,'bold'),bd=8,width=6,justify=LEFT,state=DISABLED
		                ,textvariable=E_applejuice)
txtapple.grid(row=3,column=1)

txtwatermelon = Entry(Drinks_F,font=('arial',16,'bold'),bd=8,width=6,justify=LEFT,state=DISABLED
		                ,textvariable=E_watermelonjuice)
txtwatermelon.grid(row=4,column=1)

txtlassi = Entry(Drinks_F,font=('arial',16,'bold'),bd=8,width=6,justify=LEFT,state=DISABLED
		                ,textvariable=E_lassi)
txtlassi.grid(row=5,column=1)

txtmilkshek = Entry(Drinks_F,font=('arial',16,'bold'),bd=8,width=6,justify=LEFT,state=DISABLED
		                ,textvariable=E_milkshek)
txtmilkshek.grid(row=6,column=1)

txtColdCoffee = Entry(Drinks_F,font=('arial',16,'bold'),bd=8,width=6,justify=LEFT,state=DISABLED
		                ,textvariable=E_coldcoffee)
txtColdCoffee.grid(row=7,column=1)
#############################################Foods######################################################################

masala_dosa = Checkbutton(Food_F,text="masala_dosa\t\t\t ",variable=var9,onvalue = 1, offvalue=0,
		                font=('arial',16,'bold'),bg='yellow',fg="red",command=chk_dosa).grid(row=0,sticky=W)
puliyogare = Checkbutton(Food_F,text="puliyogare",variable=var10,onvalue = 1, offvalue=0,
		                font=('arial',16,'bold'),bg='yellow',fg="red",command=chk_puliyogare).grid(row=1,sticky=W)
pizza = Checkbutton(Food_F,text="E_pizza ",variable=var11,onvalue = 1, offvalue=0,
		                font=('arial',16,'bold'),bg='yellow',fg="red",command=chk_pizza).grid(row=2,sticky=W)
HamBurger = Checkbutton(Food_F,text="Burger ",variable=var12,onvalue = 1, offvalue=0,
		                font=('arial',16,'bold'),bg='yellow',fg="red",command=chk_burger).grid(row=3,sticky=W)
Sandwich = Checkbutton(Food_F,text="Sandwich ",variable=var13,onvalue = 1, offvalue=0,
		                font=('arial',16,'bold'),bg='yellow',fg="red",command=chk_sandwich).grid(row=4,sticky=W)
Biriyani = Checkbutton(Food_F,text="Biriyani ",variable=var14,onvalue = 1, offvalue=0,
		                font=('arial',16,'bold'),bg='yellow',fg="red",command=chk_Biriyani).grid(row=5,sticky=W)
NorthIndian_meals = Checkbutton(Food_F,text="NorthIndian_meals ",variable=var15,onvalue = 1, offvalue=0,
		                font=('arial',16,'bold'),bg='yellow',fg="red",command=chk_northindian).grid(row=6,sticky=W)
SouthIndian_meals = Checkbutton(Food_F,text="SouthIndian_meals ",variable=var16,onvalue = 1, offvalue=0,
		                font=('arial',16,'bold'),bg='yellow',fg="red",command=chk_southindian).grid(row=7,sticky=W)
################################################Entry Box For Cake##########################################################
txtmasalaDosa=Entry(Food_F,font=('arial',16,'bold'),bd=8,width=6,justify=LEFT,state=DISABLED,
		                textvariable=E_masaladosa)
txtmasalaDosa.grid(row=0,column=1)

txtpuliyogare=Entry(Food_F,font=('arial',16,'bold'),bd=8,width=6,justify=LEFT,state=DISABLED,
		                textvariable=E_pulliyogare)
txtpuliyogare.grid(row=1,column=1)

txtPizza=Entry(Food_F,font=('arial',16,'bold'),bd=8,width=6,justify=LEFT,state=DISABLED,
		                textvariable=E_pizza)
txtPizza.grid(row=2,column=1)

txtBurger=Entry(Food_F,font=('arial',16,'bold'),bd=8,width=6,justify=LEFT,state=DISABLED,
		                textvariable=E_ricebath)
txtBurger.grid(row=3,column=1)

txtSandwich=Entry(Food_F,font=('arial',16,'bold'),bd=8,width=6,justify=LEFT,state=DISABLED,
		                textvariable=E_sandwich)
txtSandwich.grid(row=4,column=1)

txtBiriyani=Entry(Food_F,font=('arial',16,'bold'),bd=8,width=6,justify=LEFT,state=DISABLED,
		                textvariable=E_biriyani)
txtBiriyani.grid(row=5,column=1)

txtnorthIndian=Entry(Food_F,font=('arial',16,'bold'),bd=8,width=6,justify=LEFT,state=DISABLED,
		                textvariable=E_northindian)
txtnorthIndian.grid(row=6,column=1)

txtsouthIndian=Entry(Food_F,font=('arial',16,'bold'),bd=8,width=6,justify=LEFT,state=DISABLED,
		                textvariable=E_southindian)
txtsouthIndian.grid(row=7,column=1)
###########################################ToTal Cost################################################################################
lblCostofDrinks=Label(Cost_F,font=('arial',14,'bold'),text='Cost of Drinks\t',bg='yellow',
		        fg='red',justify=CENTER)
lblCostofDrinks.grid(row=0,column=0,sticky=W)
txtCostofDrinks=Entry(Cost_F,bg='white',bd=7,font=('arial',14,'bold'),
		                insertwidth=2,justify=RIGHT,textvariable=CostofDrinks)
txtCostofDrinks.grid(row=0,column=1)

lblCostofFood=Label(Cost_F,font=('arial',14,'bold'),text='Cost of Foods  ',bg='yellow',
		        fg='red',justify=CENTER)
lblCostofFood.grid(row=1,column=0,sticky=W)
txtCostofFood=Entry(Cost_F,bg='white',bd=7,font=('arial',14,'bold'),
		                insertwidth=2,justify=RIGHT,textvariable=CostofFood)
txtCostofFood.grid(row=1,column=1)

lblServiceCharge=Label(Cost_F,font=('arial',14,'bold'),text='Service Charge',bg='yellow',
		        fg='red',justify=CENTER)
lblServiceCharge.grid(row=2,column=0,sticky=W)
txtServiceCharge=Entry(Cost_F,bg='white',bd=7,font=('arial',14,'bold'),
		                insertwidth=2,justify=RIGHT,textvariable=ServiceCharge)
txtServiceCharge.grid(row=2,column=1)
###########################################################Payment information###################################################

lblPaidTax=Label(Cost_F,font=('arial',14,'bold'),text='\tPaid Tax',bg='yellow',fg="red",bd=7,justify=CENTER)
lblPaidTax.grid(row=0,column=2,sticky=W)
txtPaidTax=Entry(Cost_F,bg='white',bd=7,font=('arial',14,'bold'),
		                insertwidth=2,justify=RIGHT,textvariable=PaidTax)
txtPaidTax.grid(row=0,column=3)

lblSubTotal=Label(Cost_F,font=('arial',14,'bold'),text='\tSub Total',bg='yellow',fg="red",bd=7,
		       justify=CENTER)
lblSubTotal.grid(row=1,column=2,sticky=W)
txtSubTotal=Entry(Cost_F,bg='white',bd=7,font=('arial',14,'bold'),
		                insertwidth=2,justify=RIGHT,textvariable=SubTotal)
txtSubTotal.grid(row=1,column=3)

lblTotalCost=Label(Cost_F,font=('arial',14,'bold'),text='\tTotal',bg='yellow',fg="red",bd=7,
		        justify=CENTER)
lblTotalCost.grid(row=2,column=2,sticky=W)
txtTotalCost=Entry(Cost_F,bg='white',bd=7,font=('arial',14,'bold'),
		                insertwidth=2,justify=RIGHT,textvariable=TotalCost)
txtTotalCost.grid(row=2,column=3)

#############################################RECEIPT###############################################################################
txtReceipt=Text(Receipt_F,width=46,height=100,bg='white',bd=4,font=('arial',12,'bold'))
txtReceipt.grid(row=0,column=0)


###########################################BUTTONS################################################################################
btnTotal=Button(Buttons_F,padx=16,pady=1,bd=7,fg='red',font=('arial',16,'bold'),width=4,text='Total',
		                bg='yellow',command=CostofItem).grid(row=0,column=0)
btnReceipt=Button(Buttons_F,padx=16,pady=1,bd=7,fg='red',font=('arial',16,'bold'),width=4,text='Receipt',
		                bg='yellow',command=Receipt).grid(row=0,column=1)
btnReset=Button(Buttons_F,padx=16,pady=1,bd=7,fg='red',font=('arial',16,'bold'),width=4,text='Reset',
		                bg='yellow',command=Reset).grid(row=0,column=2)
btnExit=Button(Buttons_F,padx=16,pady=1,bd=7,fg='red',font=('arial',16,'bold'),width=4,text='Exit',
		                bg='yellow',command=iExit).grid(row=0,column=3)
mainloop()
